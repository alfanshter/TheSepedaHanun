package dipdip.android.dip.com.hanun;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;

import dipdip.android.dip.com.hanun.SessionManager.Preferences;

public class AkunActivity extends Activity {
    public static String nama = "";
    public static String usia = "";
    public static String token = "";
    public static String jenisKelamin = "";
    EditText etNama, etUsia, etJenis;
    Button logout;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_akun);
        etNama = (EditText)findViewById(R.id.editText7);
        etUsia = (EditText)findViewById(R.id.editText8);
        etJenis = (EditText)findViewById(R.id.editText9);
        logout = (Button)findViewById(R.id.btn_logout);
        mAuth = FirebaseAuth.getInstance();

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Preferences.clearLoggedInUser(getBaseContext());
                Intent i = new Intent(getBaseContext(), LoginActivity.class);
                startActivity(i);
                finish();
            }
        });

        etNama.setText(nama);
        etUsia.setText(usia);
        etJenis.setText(jenisKelamin);
    }

    public void onHome(View v)
    {
        Intent i = new Intent(getBaseContext(), HomeActivity.class);
        startActivity(i);
        finish();
    }
    public void onRiwayat(View v)
    {
        Intent i = new Intent(getBaseContext(), RiwayatActivity.class);
        startActivity(i);
        finish();
    }
    public void onAkun(View v)
    {
        Intent i = new Intent(getBaseContext(), AkunActivity.class);
        startActivity(i);
        finish();
    }
}
