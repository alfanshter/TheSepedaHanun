package dipdip.android.dip.com.hanun.Network;

public class MyResponse {
    public int success;

}
